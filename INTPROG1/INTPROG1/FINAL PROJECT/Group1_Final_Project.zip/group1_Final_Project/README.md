# Group 1 Team Profile (one website)

Built only from the repo PanosoChristianO-INTPROG-Integrative-Programming-Technologies-1.
Combines all four exercises in one page (design in css/style.css, functions in js/script.js):
1. Team profile cards (Exercise 1)
2. Live search box and "View Profile" pop-up (Exercise 2)
3. Filter by member with the GET method (Exercise 3)
4. Filter by member with the POST method (Exercise 4)

## Run (VS Code terminal, inside this folder)
    php -S localhost:8000
Then open http://localhost:8000
